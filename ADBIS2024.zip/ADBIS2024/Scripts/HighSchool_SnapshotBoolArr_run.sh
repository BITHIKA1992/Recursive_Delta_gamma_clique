#!/bin/bash"

rootdir="./ADBIS_Project"
dataset="HighSchool"
filename="HighSchoolProcessed.txt"
method="SnapshotBoolArr"
delta=(90 180 540 1080 2160 3240 4320 5400 6480)
gamma=(2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)
dt=1
resultdir="${rootdir}/Results/${dataset}/${method}/"

if [[ ! -e ${resultdir} ]]; then
    mkdir -p ${resultdir}
elif [[ ! -d ${resultdir} ]]; then
    echo "${resultdir} already exists but is not a directory" 1>&2
fi

for i in ${!delta[@]}; do
	for j in ${!gamma[@]}; do
		basefile="${resultdir}base_result_${delta[$i]}_${gamma[$j]}.json"
		if [[ ! -e ${basefile} ]]; then
			echo "${basefile}"
			python -u ${rootdir}/Methods/${method}/main.py --rootdir ${rootdir} --dataset ${dataset}  --filename ${filename} --method ${method} --delta ${delta[$i]}  --gamma ${gamma[$j]} --dt ${dt} > ${resultdir}base_nohup_${delta[$i]}_${gamma[$j]}.out 2> ${resultdir}base_nohup_${delta[$i]}_${gamma[$j]}.err
		fi
	done
done