#!/bin/bash"

rootdir="./ADBIS_Project"
dataset="HighSchool"
filename="HighSchoolProcessed.txt"
method="BKDeltaGamma"
delta=(90 180 540 1080 2160 3240 4320 5400 6480)
gamma=(2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)
dt=1
pivotlabel=0
resultdir="${rootdir}/Results/${dataset}/${method}/"
datafile="${rootdir}/Dataset/${dataset}/${filename}"
statfile="stat_${dataset}_${method}"
cliquefile="cliqueset_${dataset}_${method}"


if [[ ! -e ${resultdir} ]]; then
    mkdir -p ${resultdir}
elif [[ ! -d ${resultdir} ]]; then
    echo "${resultdir} already exists but is not a directory" 1>&2
fi

for i in ${!delta[@]}; do
	for j in ${!gamma[@]}; do
		basefile="${resultdir}base_result_${delta[$i]}_${gamma[$j]}_${pivotlabel}.json"
		if [[ ! -e ${basefile} ]]; then
			echo "${basefile}"
			cat ${datafile} | python -u ${rootdir}/Methods/${method}/temporal-cliques.py --rootdir ${rootdir} --dataset ${dataset} --method ${method} --dt ${dt} --delta ${delta[$i]} --gamma ${gamma[$j]} --pivoting ${pivotlabel} > ${resultdir}base_nohup_${delta[$i]}_${gamma[$j]}_${pivotlabel}.out 2> ${resultdir}base_nohup_${delta[$i]}_${gamma[$j]}_${pivotlabel}.err &
		fi
	done
done


