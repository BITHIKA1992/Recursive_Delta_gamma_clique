# -*-coding:utf8*-
import sys
from collections import deque
#import networkx as nx
import itertools
import pandas as pd
#from itertools import combinations
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d
import bisect

from Clique_2p import Clique


class CliqueMaster:

    def __init__(self):
        self._S = deque()
        self._S_set = set()
        self._R = set()
        self._times = dict()
        self._nodes = dict()  
        #self._graph = nx.Graph() ## removed- Not required, covered by "nodes" structure which is adjacency list
        self._clique_dict = dict()
        self._clique_dict[2] = dict() #initialize for 2-sized cliques
        self._result_list = []
        self._iternum = 0
        self._maxsize = 0
        self._maxdur = 0
        #self._S_count = None

    def addClique(self, c):
        """ Adds a clique to S,
        checking beforehand that this clique is not already present in S. """
        if c not in self._S_set:
            self._S.appendleft(c)
            #self._S.append(c)
            self._S_set.add(c)

    def getClique(self):
        c = self._S.pop()
        #sys.stderr.write("\nGetting clique " + str(c) + "\n")  #### ----------------- print removed 12122019
        return c



#### Bithika:           
    def printInitialCliques(self):
        for c in self._S:
            #sys.stdout.write(str(c) + ' neighbor candidates:' + str(c._candidates) + "\n")
            sys.stdout.write(str(c) + "\n")
            #self._result_list.append([list(c._X), len(c._X), c._tb, c._te, c._te - c._tb])  ### initial clique test
        print("Initial Clique dictionary:===")
        print(self._clique_dict)

#### Bithika:           
    def printAllCliques(self):
        for c in self._S_set:
            #sys.stdout.write(str(c) + ' neighbor candidates:' + str(c._candidates) + "\n")
            sys.stdout.write(str(c) + "\n")
            #self._result_list.append([list(c._X), len(c._X), c._tb, c._te, c._te - c._tb])  ### initial clique test
        print("All Clique dictionary:===")
        print(self._clique_dict)
        
#### Bithika:           
    def printAllMaximalCliques(self):
        for c in self._R:
            #sys.stdout.write(str(c) + ' neighbor candidates:' + str(c._candidates) + "\n")
            sys.stdout.write(str(c) + "\n")
            #self._result_list.append([list(c._X), len(c._X), c._tb, c._te, c._te - c._tb])  ### initial clique test
        

#### Bithika:
    def printCliquesDistribution(self, delta):
        Maximal_Clique_df = pd.DataFrame(self._result_list, columns=['node_set', 'cardinality', 'tb', 'te', 'duration'])
        Maximal_Clique_df = Maximal_Clique_df[['cardinality','duration']]
        Maximal_Clique_df = Maximal_Clique_df.astype(int) 
        Maximal_Clique_df = Maximal_Clique_df[ ~((Maximal_Clique_df['duration'] == 2*delta) & (Maximal_Clique_df['cardinality'] == 2))]       
        Maximal_Cardinality_df = Maximal_Clique_df.groupby(['cardinality'], sort=True).size().reset_index(name='counts')
        Maximal_Duration_df = Maximal_Clique_df.groupby(['duration'], sort=True).size().reset_index(name='counts')
        Maximal_df = Maximal_Clique_df.groupby(['cardinality','duration'], sort=True).size().reset_index(name='counts')
        print("Maximal cardinality DF:")
        print(Maximal_Cardinality_df)
        print("Maximal duration DF:")
        print(Maximal_Duration_df)
        print("Maximal DF:")
        print(Maximal_df)
        plt.bar(Maximal_Cardinality_df['cardinality'], Maximal_Cardinality_df['counts'])
        #plt.ylim(0,700)
        plt.xlabel('Cardinality')
        plt.ylabel('Count')
        plt.title('Frequency Distribution of Maximal Cardinality')
        plt.show()
        plt.plot(Maximal_Duration_df['duration'], Maximal_Duration_df['counts'])
        #plt.ylim(0,20)
        plt.xlabel('Duration')
        plt.ylabel('Count')
        plt.title('Frequency Distribution of Maximal Duration')
        plt.show()
        #Maximal_df = Maximal_df[1:]
        #Maximal_df[['cardinality','counts']].boxplot(by='cardinality')
        #plt.show()
        fig = plt.figure()
        ax = plt.axes(projection='3d')
        ax.scatter( Maximal_df['cardinality'], Maximal_df['duration'], Maximal_df['counts'], c=Maximal_df['counts'])
        ax.set_title('Detailed View on #Maximal Cliques')
        ax.set_xlabel('Cardinality')
        ax.set_ylabel('Duration')
        ax.set_zlabel('Count')
        plt.show()

#### Bithika:
    def getInitDeltaGammaCliques(self, delta, gamma, dt):
        for e in self._times.keys():
            temp_ts = self._times[e]
            X = set(e)
            u, v = list(X)
            Y = self._nodes[u] # this is a set
            Z = self._nodes[v]
            neighborlist = (Y.intersection(Z))-X
            #print('X: ', X, 'Y: ',Y, 'Z: ', Z, 'neighborlist: ', neighborlist)
            if len(temp_ts) >= gamma:
                for i in range(len(temp_ts)):
                    if i == 0:
                        current_list = []
                        current_list.append(temp_ts[i])
                        #print(current_list, i)
                        #print('if : case 1')
                    elif len(current_list) < gamma:
                        if (temp_ts[i] - current_list[0]) <= delta:  
                            current_list.append(temp_ts[i])
                            #print(current_list, i)
                            #print('elif : case 2')  
                        else:
                            current_list = []
                            links_1 = self._times[e][bisect.bisect_left(self._times[e], temp_ts[i] - delta):bisect.bisect_right(self._times[e], temp_ts[i])]
                            for l in links_1:
                                current_list.append(l)

                    elif len(current_list) >= gamma :
                        if (current_list[len(current_list)-gamma]+1+delta) >= temp_ts[i]:
                        #if (temp_ts[i] - temp_ts[i-gamma+1]) <= delta:  
                            current_list.append(temp_ts[i])
                        else:
                            tb = current_list[gamma-1] - delta
                            te = current_list[len(current_list) - gamma] + delta
                            time = (tb,te)
                            self.addClique(Clique((e, time), neighborlist))   ### neighborlist
                            current_list = []
                            links_1 = self._times[e][bisect.bisect_left(self._times[e], temp_ts[i] - delta):bisect.bisect_right(self._times[e], temp_ts[i])]
                            for l in links_1:
                                current_list.append(l)
                                #print(current_list, i)
                                #print('elif else : case 4')
                    #else:
                        #None

                    if (i== len(temp_ts)-1) and len(current_list) >= gamma:
                        #print(current_list, i)
                        tb = current_list[0+gamma-1] - delta
                        te = current_list[len(current_list) - gamma] + delta
                        time = (tb,te)
                        self.addClique(Clique((frozenset(e), time), neighborlist))   #### neighborlist
                        current_list = []
                        #print('if : case 6')
        
        for c in self._S:
            if frozenset(c._X) in self._clique_dict[2]:
                self._clique_dict[2][frozenset(c._X)].append((c._tb,c._te))
            else:
                self._clique_dict[2][frozenset(c._X)] = []
                self._clique_dict[2][frozenset(c._X)].append((c._tb,c._te))

#### Bithika:
    def getDeltaGammaCliques(self, delta, gamma, dt):
        NOT_MAXIMAL = True
        maxsize = 0
        maxdur = 0
        iternum = 0
        k_curr = 2
        k_new = k_curr + 1
        while(NOT_MAXIMAL):
            T = deque()
            print("Processing {} sized cliques to get {} sized cliques".format(k_curr,k_new))
            self._clique_dict[k_new] = dict()
            while(len(self._S) != 0):
                iternum += 1
                c = self.getClique()
                
                is_max = True
                candidates = c._candidates
                for node in candidates:
                    xn = [ h for h in c._X]
                    xn.append(node)
                    X_new = c._X.union([node])
                    if frozenset(X_new) in self._clique_dict[k_new]:
                        if (c._tb, c._te) in self._clique_dict[k_new][frozenset(X_new)]:
                            is_max = False
                    else:
                        check_flag, temp_ts = self.checkClique(node, frozenset(c._X))  ##_with2
                        if check_flag:
                            #neighbors_node = self._graph.neighbors(node)
                            neighbors_node = self._nodes[node]
                            neighborlist = candidates.intersection(neighbors_node).difference(X_new) #difference(node)
                            for element in itertools.product(*temp_ts):
                                max_tb = []
                                min_te = []
                                for e in element:
                                    max_tb.append(e[0])
                                    min_te.append(e[1])
                                tb = max(max_tb)
                                te = min(min_te)
                                if (te -tb) >= delta : 
                                    c_add = Clique((frozenset(X_new), (tb, te)), neighborlist)
                                    T.appendleft(c_add)
                                    if frozenset(xn) in self._clique_dict[k_new]:
                                        self._clique_dict[k_new][frozenset(X_new)].append((tb,te))
                                    else:
                                        self._clique_dict[k_new][frozenset(X_new)] = []
                                        self._clique_dict[k_new][frozenset(X_new)].append((tb,te))
                                    
                                    if tb == c._tb and te == c._te:
                                        is_max = False

                if is_max:
                    #sys.stderr.write(str(c) + " is maximal\n") #### ----------------- print removed 12122019
                    maxsize = max(maxsize, len(c._X))
                    maxdur = max(maxdur, c._te - c._tb)
                    #sys.stderr.write("M " + str(iternum) + " " + str(maxsize) + " " + str(maxdur) + "\n")  #### ----------------- print removed 12122019
                    self._iternum = iternum
                    self._maxsize = maxsize
                    self._maxdur = maxdur
                    self._result_list.append([list(c._X), len(c._X), c._tb, c._te, c._te - c._tb])
                    self._R.add(c)

  
            if len(T) > 0: 
                for t in T:
                    self.addClique(t)                 
            else:
                NOT_MAXIMAL = False
                if len(self._clique_dict[k_new]) == 0:
                    del self._clique_dict[k_new]
                
            k_curr = k_new
            k_new = k_curr + 1

        return self._R

                        

#### Bithika:
    def checkClique(self, node, X):
        temp_ts = []
        temp_ts.append(self._clique_dict[len(X)][X])
        for u in X:
            Z=set(X)-set([u])
            Z_new=Z.union([node])
            Y = frozenset(Z_new)
            #l=[i for i in Z]
            #l.append(node)
            #Y = frozenset(l)
            #Y = frozenset([u, node])
            if Y not in self._clique_dict[len(Y)]:
                return (False, 0)
            else:
                temp_ts.append(self._clique_dict[len(Y)][Y])
        return (True, temp_ts)

#### Bithika:
    def checkClique_with2(self, node, X):
        temp_ts = []
        X_new = list(X)
        X_new.append(node)
        comb = itertools.combinations(X_new, 2)
        for u in comb:
            Y = frozenset([u[0], u[1]])
            #l=[i for i in Z]
            #l.append(node)
            #Y = frozenset(l)
            #Y = frozenset([u, node])
            if Y not in self._clique_dict[len(Y)]:
                return (False, 0)
            else:
                temp_ts.append(self._clique_dict[len(Y)][Y])
        return (True, temp_ts)




    def __str__(self):
        msg = ""
        for c in self._R:
            msg += str(c) + "\n"
        return msg
