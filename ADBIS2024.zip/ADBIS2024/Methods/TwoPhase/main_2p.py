import sys
#import networkx as nx

import time as TM
import os
import psutil
import pickle
from collections import defaultdict
import itertools
import numpy as np
import argparse

from CliqueMaster_2p import CliqueMaster


parser = argparse.ArgumentParser()
parser.add_argument("--rootdir", type=str, help="Root directory of the project")
parser.add_argument("--dataset", type=str, help="Name of the dataset")
parser.add_argument("--filename", type=str, help="Name of the file to read data")
parser.add_argument("--method", type=str, help="Name of the algorithm(method) which is used to compute")
parser.add_argument("--delta", type=int, help="Integer Delta Value greater than zero")
parser.add_argument("--gamma", type=int, help="Integer gamma Value greater than zero")
parser.add_argument("--dt", type=int, help="Integer dt Value greater than zero")
args = parser.parse_args()

'''
rootdir = "C:\\Users\\hp\\Code\\Delta-Gamma-Clique\\Snapshot-based-enumeration"
#data_dir = "Dataset"
dataset = "toy"
filename = "sample_linked_stream.txt"


delta = 3
gamma = 1
dt = 1

'''
rootdir = args.rootdir
dataset = args.dataset
filename = args.filename
method = args.method
delta = args.delta
gamma = args.gamma
dt = args.dt

if len(sys.argv) == 1:
    print("Try -h to know the arguments")
    exit()
    
    
data_file = os.path.join(rootdir, "Dataset", dataset, filename)
result_dir = os.path.join(rootdir, "Results", dataset, method) 

if not os.path.exists(result_dir):
    # Create the directory
    os.makedirs(result_dir)


################  start 
def read_data(fname):
    # Initiate
    nodes = dict()
    times = dict()

    # Create Graph
    #G = nx.Graph()
    # Read stream
    
    f = open(os.path.join(fname), "r")
    lines = f.readlines()
    f.close()
    nb_lines = 0
    #start_time = TM.time()
    for line in lines:
        t, u, v = line.strip().split(' ')
        t = int(t)
        
        link = frozenset([u, v])

        ##Add the edge in the static graph G
        #G.add_edge(str(u), str(v))

        # Populate data structures
        if link not in times:
            times[link] = []
        times[link].append(t)
        
        if u not in nodes:
            nodes[u] = set()

        if v not in nodes:
            nodes[v] = set()

        nodes[u].add(v)
        nodes[v].add(u)

        nb_lines += 1
        
    print("Number of links: {}".format(nb_lines))
    print("Number of Nodes: {}".format(len(nodes)))
    print("Number of Edges: {}".format(len(times)))
    
    return nodes, times



def get_all_durationwise_maximal_cliques(fname, delta, gamma, dt=1):

    if delta < 0:
        print("Delta must be positive.\n")
        return

    if gamma < 0:
        print("Gamma must be positive.\n")
        return
        
    nodes, times = read_data(fname)
    
    Cm = CliqueMaster()
    Cm._times = times
    Cm._nodes = nodes
    #Cm._nodes_attribute = dict()
    #Cm._graph = G
    #print("Size of Graph:", sys.getsizeof(G)/1024)

    ##### Bithika:
    Cm.getInitDeltaGammaCliques(delta, gamma, dt)
    #stop#Cm.printInitialCliques()
    Cm.getDeltaGammaCliques(delta, gamma, dt) ## Computes the maximal and stores in Cm._R
    #stop#Cm.printAllCliques()
    
    return Cm


########################################################################################### 
###                                          main                                       ### 
###########################################################################################
start_time = TM.time()
Cm = get_all_durationwise_maximal_cliques(data_file, delta, gamma, dt=1)
end_time = TM.time()

Cm.printAllMaximalCliques()

#### Bithika: added clique count function
def get_count_all_temporal_cliques(Cm, delta, dt ):
    
    S_count = np.zeros([Cm._maxsize -1 , int((Cm._maxdur - delta)/dt)+1], dtype=int)
    for k_curr in Cm._clique_dict.keys():
        for X in Cm._clique_dict[k_curr].keys():
            for I in Cm._clique_dict[k_curr][X]:
                duration = I[1]-I[0]
                c = 1
                while duration >= delta:
                    S_count[len(X)-2][int((duration - delta)/dt)] += c
                    c += 1
                    duration -= dt
                #print(X,I, self._S_count)
    
    return S_count

### All Delta gamm - clique count        
print("All Delta,gamma Clique count - Result")
S_count = get_count_all_temporal_cliques(Cm, delta, dt )
print(S_count)


maximal_clique_set = set()
for c in Cm._R:
    maximal_clique_set.add((c._X, (c._tb, c._te)))

op_fname = "maximal_clique_set" + "_" + str(delta) + "_" + str(gamma) + ".pkl"         
with open(os.path.join(result_dir, op_fname), 'wb') as file: 
    #pickle.dump(Cm._R, file) 
    pickle.dump(maximal_clique_set, file)

op_fname = "all_temporal_clique_count" + "_" + str(delta) + "_" + str(gamma) + ".pkl" 
with open(os.path.join(result_dir, op_fname), 'wb') as file:
    pickle.dump(S_count, file)

   
op_fname = "dm_clique_dict"+"_"+str(delta)+"_"+str(gamma)+".pkl" 
with open(os.path.join(result_dir, op_fname), 'wb') as file: 
    pickle.dump(Cm._clique_dict, file) 

 
if len(Cm._R) > 0: 
    ### Maximal Clique Counts and statistics
    print("Maximal Clique Count: ", str(len(Cm._R)), \
            "Maximum Cardinality: ", str(Cm._maxsize), \
            "Maximum Duration: ", str(Cm._maxdur),\
            "Delta-degenracy: ", str(Cm._maxsize-1))
        
### Computational Time and space
print("Computational Time: ", str((end_time - start_time))," sec." )    
process = psutil.Process(os.getpid())
compspace = process.memory_info().rss/1024/1024
print("Used Memory:", compspace, "MB")


#### Stat result saving 
import json
base_result = dict()
base_result['dataset'] = dataset 
base_result['delta'] = delta
base_result['gamma'] = gamma

base_result['clique_count'] = len(Cm._R)
base_result['maxsize'] = Cm._maxsize
base_result['maxdur'] = Cm._maxdur

base_result['method'] = method
base_result['comptime'] = (end_time - start_time)
base_result['compspace'] = compspace

op_fname = "base_result"+"_"+str(delta)+"_"+str(gamma)+".json"
with open(os.path.join(result_dir, op_fname), "w") as file:
    json.dump(base_result, file)


#Cm.printCliquesDistribution(delta)




