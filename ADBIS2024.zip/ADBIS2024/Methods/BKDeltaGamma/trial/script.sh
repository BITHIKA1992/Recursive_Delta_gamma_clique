
cat /home/rs/19CS92R05/Work_With_Suman/Delta-Gamma-Clique/Snapshot-based-enumeration/Dataset/Infectious/infectiousSmall.txt | python temporal-cliques.py -d 30 -g 10 -s stat_InfectiousSmall_BKdeltagamma_30_10.txt -c cliqueset_InfectiousSmall_BKdeltagamma_30_10.pkl
