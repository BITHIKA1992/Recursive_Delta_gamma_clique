

A Recursive Approach for Maximal $(\Delta, \gamma)$-Clique Enumeration in Temporal Networks, Bithika Pal, ADBIS 2024

Reused the code from http://fpt.akt.tu-berlin.de/temporalcliques/ 
Orginial version was in Python 2.7

Currently in Python 3

Bithika Pal
03-July-2024