
Delta-Clique Enumeration in Temporal Graphs
-------------------------------------------

This tool enumerates all maximal delta-cliques in a given temporal
graph, as described in the paper

       Enumerating Maximal Cliques in Temporal Graphs, Anne-Sophie
       Himmel, Hendrik Molter, Rolf Niedermeier, and Manuel Sorge, to
       appear.

If you use this code in scientific research, please cite the above
article.

The current version of this tool can be obtained from

    http://fpt.akt.tu-berlin.de/temporalcliques/ .

The tool is distributed under the terms of the GNU General Public
License (GPL, see COPYING).

The tool is written in Python 2.7.11. To run it, type

    cat temporal-graph | ./temporal-cliques.py

Herein, temporal-graph is a file containing a temporal graph (a
multigraph with integer edge labels) encoded in lines of the form

     t u v

describing an edge between vertex u and vertex v at time step t.
Vertex names can be arbitrary strings but the time step t has to be an
integer. Such temporal graphs can be obtained, for example, from
sociopatterns.org.  Additional, optional arguments are described when
calling ./temporal-cliques.py -h .

compute-degeneracy.py is a tool to compute the delta-slice degeneracy
of a temporal graph as defined in the paper cited above.

-- Manuel Sorge
   12th May 2016

