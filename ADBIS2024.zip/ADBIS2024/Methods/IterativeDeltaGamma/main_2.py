from CliqueMaster_2 import CliqueMaster
from Clique_2 import Clique
import sys
import networkx as nx
import bisect
import time as TM
import os
import psutil
import pickle
import json
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--rootdir", type=str, help="Root directory of the project")
parser.add_argument("--dataset", type=str, help="Name of the dataset")
#parser.add_argument("--filename", type=str, help="Name of the file to read data")
parser.add_argument("--method", type=str, help="Name of the algorithm(method) which is used to compute")
parser.add_argument("--delta", type=int, help="Integer Delta Value greater than zero")
parser.add_argument("--gamma", type=int, help="Integer gamma Value greater than zero")
parser.add_argument("--dt", type=int, help="Integer dt Value greater than zero")
args = parser.parse_args()


if len(sys.argv) == 1:
    print("cat <datafile> | python <>.py <arguments>; Try -h to know the arguments")
    exit()
    
rootdir = args.rootdir
dataset = args.dataset
method = args.method
delta = args.delta
gamma = args.gamma
dt = args.dt

#data_file = os.path.join(rootdir, "Dataset", dataset, filename)
result_dir = os.path.join(rootdir, "Results", dataset, method) 
if not os.path.exists(result_dir):
    # Create the directory
    os.makedirs(result_dir)
output_file_name = os.path.join(result_dir,"maximal_clique_set" + "_" + str(delta) + "_" + str(gamma) + ".pkl"  )

# Initiate
Cm = CliqueMaster()
times = dict()
nodes = dict()
nb_lines = 0
resurrect = False


if delta < 0:
    sys.stderr.write("Delta must be positive.\n")
    sys.exit(1)
    
if gamma < 0:
    sys.stderr.write("Gamma must be positive.\n")
    sys.exit(1)

# Create Graph
G = nx.Graph()
# Read stream

for line in sys.stdin:
    contents = line.split(" ")
    t = int(contents[0])
    u = contents[1].strip()
    v = contents[2].strip()

    link = frozenset([u, v])
    time = (t, t)
    
    ##Add the edge in the static graph G
    G.add_edge(str(u), str(v))

    # This a new instance
    #Cm.addClique(Clique((link, time), set([])))

    # Populate data structures
    if link not in times:
        times[link] = []
    if t not in times[link]:
        times[link].append(t)

    if u not in nodes:
        nodes[u] = set()

    if v not in nodes:
        nodes[v] = set()

    nodes[u].add(v)
    nodes[v].add(u)
    nb_lines = nb_lines + 1
Cm._times = times
Cm._nodes = nodes
Cm._graph = G
sys.stderr.write("Processed " + str(nb_lines) + " from stdin\n")

#print(G.edges())

##### Bithika:
start_time = TM.time()

for e in G.edges():
    #print(e[0],e[1])
    link = frozenset([e[0], e[1]])
    X = set([e[0],e[1]])
    Y = set(list(G.neighbors(e[0])))
    Z = set(list(G.neighbors(e[1])))
    neighborlist = (Y.intersection(Z))-X
    temp_ts = times[frozenset([e[0],e[1]])]
    temp_ts.sort()
    if len(temp_ts) >= gamma:
        for i in range(len(temp_ts) - gamma +1):
             if (temp_ts[i + gamma-1] - temp_ts[i]) == delta:
                tb = temp_ts[i]
                te = temp_ts[i + gamma-1]
                time = (tb, te)
                Cm.addClique(Clique((link, time), neighborlist))
             elif (temp_ts[i + gamma-1] - temp_ts[i]) < delta:
                tb = temp_ts[i]
                te = temp_ts[i + gamma-1]
                time1 = (te-delta, te)
                time2 = (tb, tb + delta)	
                Cm.addClique(Clique((link, time1), neighborlist))
                Cm.addClique(Clique((link, time2), neighborlist))
		


#Cm.printInitialCliques()
Cm.getDeltaGammaCliques(delta, gamma, dt)		
#Cm.printCliques()

end_time = TM.time()

### Save the output(maximal-clique-set)
'''
with open(output_file_name, 'wb') as handle:
    pickle.dump(Cm._R, handle)
'''
process = psutil.Process(os.getpid())
compspace=process.memory_info().rss/1024/1024
if len(Cm._R) > 0: 
    print("Number of cliques: ", str(len(Cm._R)) )
    print("Delta: ", str(delta) )
    print("Max cardinality: ", str(Cm._maxsize))
    print("Max duration: ", str(Cm._maxdur))
    print("Number of iterations: ", str(Cm._iternum))
    print("Computational Time: ", end_time - start_time)
    print("Used Memory:", compspace, "MB")  # in bytes 


# Restart execution
#R = Cm.getDeltaCliques(delta)
#sys.stdout.write("# delta = %d\n" % (delta))
#Cm.printCliques()


#Cm.printCliquesDistribution(delta)

base_result = dict()

base_result['dataset'] = dataset 
base_result['delta'] = delta
base_result['gamma'] = gamma

base_result['clique_count'] = len(Cm._R)
base_result['maxsize'] = Cm._maxsize
base_result['maxdur'] = Cm._maxdur
base_result['iternum'] = Cm._iternum

base_result['method'] = method
base_result['comptime'] = end_time - start_time
base_result['compspace'] = compspace

op_fname = "base_result"+"_"+str(delta)+"_"+str(gamma)+".json"
with open(os.path.join(result_dir, op_fname), "w") as file:
    json.dump(base_result, file)

print("Finished")