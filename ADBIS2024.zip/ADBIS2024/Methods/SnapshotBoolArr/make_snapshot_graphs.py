import pandas as pd
import os
import math
import numpy as np
import statistics as st
from util import create_graph, get_degeneracy_ordering
from collections import defaultdict

root_dir = "."
data_dir = "Dataset"
dataset = "toy"
filename = "sample_linked_stream.txt"
data_file = os.path.join(root_dir, data_dir, dataset,filename)
## format t u v

data = pd.read_csv(data_file, sep=" ", header=None)
data.columns =['t', 'u', 'v']
data = data.sort_values(by = ['t', 'u', 'v'], inplace=False,ignore_index=True)

Delta = int(input("Enter Delta: "))
gamma = int(input("Enter gamma: "))
dt = int(input("Enter dt: "))


print("Delta {}, gamma {}, dt {}".format(Delta,gamma,dt))
#print(type(Delta), type(gamma), type(dt))
#print(data)

t_b = min(data['t'])
t_e = max(data['t'])

t_b_ = t_b + (gamma - 1) * dt - Delta
t_e_ = t_e - (gamma - 1) * dt + Delta

print("t_b, t_e, t_b_, t_e_: ", t_b, t_e, t_b_, t_e_)
Dz = math.floor(((t_e_ - t_b_) - Delta ) / dt) + 1  # the number of snapshot graphs
print("the number of snapshot graphs (Dz): ", Dz)

T_b_e = np.empty((2,Dz), dtype=int)
## 2-D int array to store the t_b and t_e for the snapshots
for idx, i in enumerate(range(t_b_, t_e_ + dt -Delta, dt)):
    T_b_e[0][idx] = i
    T_b_e[1][idx] = i + Delta

print(T_b_e)

## edge list creation for each snapshot graph
snap_edge_list = dict()
snap_node_list = dict()
for i in T_b_e[0][:]:
    snap_edge_list[i] = defaultdict(int) #edge list 
    snap_node_list[i] = set()

for index, row in data.iterrows():
    print(index, row['t'], row['u'], row['v'])
    for i in range(row['t'] - Delta , row['t'] +dt,  dt):
        if i >= t_b_ and i<= t_e_ - Delta:
            print(i)
            snap_edge_list[i][frozenset((row['u'], row['v']))] += 1 ## add edge with their count of occurence
            snap_node_list[i].add(row['u'])
            snap_node_list[i].add(row['v'])
            print(i, snap_edge_list[i])
    

#print(snap_edge_list[i- int(Delta)])
## print edge count of the snapshot graphs
Es = np.array([len(snap_edge_list[i]) for i in snap_edge_list.keys()], dtype=int)
Ns = np.array([len(snap_node_list[i]) for i in snap_node_list.keys()], dtype=int)
print("##### Some statistics of the snapshot graphs #####")
print("Edgecount:  max {}, min {}, mode {}, median {}, mean {}, std {}".format( max(Es), min(Es), st.mode(Es), np.median(Es), np.mean(Es), np.std(Es)))
print("Nodecount:  max {}, min {}, mode {}, median {}, mean {}, std {}".format( max(Ns), min(Ns), st.mode(Ns), np.median(Ns), np.mean(Ns), np.std(Ns)))

print("Histogram and density function of Edgecount on the snapshot-population")
temp1, temp2 = np.histogram(Es, bins=np.arange(max(Es)+1), density=True) #bins=np.arange(max(Es)+1)
temp3, temp4 = np.histogram(Es, bins=np.arange(max(Es)+1), density=False) #bins=np.arange(max(Es)+1)
print(temp1, temp3, temp4)
print("Histogram and density function of Nodecount on the snapshot-population")
temp1, temp2 = np.histogram(Ns, bins=np.arange(max(Ns)+1), density=True)
temp3, temp4 = np.histogram(Ns, bins=np.arange(max(Ns)+1), density=False)
print(temp1, temp3, temp4)

### Get the degeneracy of the snapshot graphs
Degn_s = []
Density_s = []
for i in snap_edge_list.keys():
    G = create_graph(snap_edge_list[i], snap_node_list[i], gamma)
    print(i, i+Delta)
    print([(e, G[e[0]][e[1]]['gamma']) for e in G.edges()])
    _, degeneracy =  get_degeneracy_ordering(G)
    Degn_s.append(degeneracy)
    Density_s.append(nx.density(G))
Degn_s = np.array(Degn_s, dtype=int)
print("##### Some statistics of the snapshot graphs degeneracy #####")
print("Degeneracy:  max {}, min {}, mode {}, median {}, mean {}, std {}".format( max(Degn_s), min(Degn_s), st.mode(Degn_s), np.median(Degn_s), np.mean(Degn_s), np.std(Degn_s)))
print("Histogram and density function of Degeneracy on the snapshot-population")
temp1, temp2 = np.histogram(Degn_s, bins=max(Degn_s)-1, density=True)
temp3, temp4 = np.histogram(Degn_s, bins=max(Degn_s)-1, density=False)
print(temp1, temp3, temp4)

print("##### Some statistics of the snapshot graphs density #####")
print(Density_s)


