import networkx as nx
import copy
from collections import defaultdict
    
def create_graph(edge_list, node_list=[], gamma=1):
    ## input edge_list: dict of frozenset(edge): count(gamma)
    G = nx.Graph()
    G.add_nodes_from(node_list)
    if isinstance(edge_list,defaultdict):
        edge_list = list(edge_list.items())
    elif isinstance(edge_list,set):
        edge_list = [(e, gamma) for e in edge_list]
    for e,c in edge_list:
        u, v = list(e)
        if c >= gamma:
            G.add_edge(u, v)
            G[u][v]['gamma'] = c

    return G

def get_degeneracy_ordering(G):
    L = []
    d = []
    G_ = copy.deepcopy(G)
    #print(G_.number_of_nodes())
    if G_.number_of_nodes() == 0:
        return (L, 0)
    while G_.number_of_nodes() > 0:
        min_deg_node , min_deg = min(G_.degree, key = lambda t: t[1])
        #print(min_deg_node, min_deg)
        L.insert(0,min_deg_node)
        #L.append(min_deg_node)
        d.append(min_deg)
        G_.remove_node(min_deg_node)
    #print(d)
    return (L, max(d))

def get_degree_ordering(G):
    M = [(i, G.degree(i)) for i in G.nodes()]
    M.sort(key = lambda t: t[1], reverse=True)
    return [i[0] for i in M]


if __name__ == "__main__":
    #G=nx.erdos_renyi_graph(10,0.5)
    node_list = [1,2,3,4,5,6]
    edge_list = set( [frozenset([1,2]), frozenset([1,3]), frozenset([1,4]),\
                     frozenset([2,3]), frozenset([2,4]), frozenset([2,5]),\
                     frozenset([3,4]), frozenset([3,5]), frozenset([4,6]), frozenset([5,6])])
    G=create_graph(edge_list, node_list, gamma=1)
    print(G.nodes())
    print("Edge List                 ", [(e[0], e[1], G[e[0]][e[1]]['gamma']) for e in G.edges()])
    print(get_degeneracy_ordering(G))
    print(G.degree)
