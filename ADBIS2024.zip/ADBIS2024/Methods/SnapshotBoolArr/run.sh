#!/bin/bash

delta=(120 240 360 480 600)
gamma=(1 2 3 4 5)

for i in ${!delta[@]}; do
	for j in ${!gamma[@]}; do
		echo "Delta ${delta[$i]}, gamma ${gamma[$j]}"
		nohup python main.py --root_dir /home/rs/19CS92R05/Work_With_Suman/Delta-Gamma-Clique/Snapshot-based-enumeration --dataset Infectious  --filename prosper-loans.txt --method Proposed --delta ${delta[$i]}  --gamma ${gamma[$j]} --dt 20 > /home/rs/19CS92R05/Work_With_Suman/Delta-Gamma-Clique/Snapshot-based-enumeration/Result/Infectious/Proposed/nohup_${delta[$i]}_${gamma[$j]}.out &	
	done
done

