import numpy as np
import math
import itertools
from collections import defaultdict

class TClique_storage(object):
    def __init__(self, Delta, t_b_, t_e_, dt, delta_degeneracy) -> None:
        ## input: duration is [t_b , t_e] for the snapshot or the temporal cliques with in t_b and t_e
        ## dictionary: where key is the frozenset of nodeset, and
        ##  value is the list of [t_b, t_e] -- sorted in order of t_b
        self.Dz = math.floor(((t_e_ - t_b_) - Delta ) / dt) + 1
        self.Delta, self.t_b_ , self.t_e_, self.dt = Delta, t_b_, t_e_, dt 
        self.delta_degeneracy = delta_degeneracy
        self.S_dict = dict()
        for k in range(2, self.delta_degeneracy + 2):
            self.S_dict[k] = dict()
            
        self.S_count = None
        self.max_card = 0
        self.max_duration = 0
        self.maximal_clique_count = 0
        self.clique_dict = dict() #defaultdict(list)
        for k in range(2, self.delta_degeneracy + 2):
            self.clique_dict[k] = defaultdict(list)



    def __sizeof__(self) -> int:
        return sum([len(self.S_dict[k]) for k in range(2, self.delta_degeneracy +2)])
    
    def add_clique_Deltasize(self, X, idx, t_e):
        if len(X) == 1:
            #trivial clique
            #print("Trivial Clique ", X, t_e)
            return
        if idx is None:
            idx = math.floor((t_e - self.t_b_)  / self.dt)  - math.floor(self.Delta / self.dt)
        
        for k in range(2, len(X)+1):
            comb = [frozenset(x) for x in itertools.combinations(X,k)]
            for Y in comb:
                if Y not in self.S_dict[k].keys():
                    #Dz= len([i for i in range(self.t_b_ + self.Delta, self.t_e_+ self.dt, self.dt )])
                    Dz = self.Dz 
                    self.S_dict[k][Y] = np.full((Dz), False, dtype=bool)
                #idx == idy: True
                #idy = math.floor((t_e - self.t_b_)  / self.dt)  - math.floor(self.Delta / self.dt)
                #print(Y,idx, t_e)
                self.S_dict[k][Y][idx] = True


    def get_all_cliques(self):
                                                     
        for k in range(2, self.delta_degeneracy + 2):
            for X in self.S_dict[k].keys():
                print(X, self.S_dict[k][X])
            
    def get_maximal_temporal_cliques(self):
        if len(self.clique_dict.keys()) == 0:
            self.get_all_temporal_cliques()
        
        delete_list = set()
        for k_curr in range(self.max_card,2,-1):
            for X in self.clique_dict[k_curr].keys():
                X_children = [frozenset(x) for x in itertools.combinations(X, k_curr-1)]
                for subset_X in X_children:
                    for I in self.clique_dict[k_curr][X]:    
                        if I in self.clique_dict[k_curr-1][frozenset(subset_X)]:
                            delete_list.add((subset_X, tuple(I)))
        for c in delete_list:
            (X, (tb, te)) = c
            self.clique_dict[len(X)][X].remove(tuple([tb,te]))
            
    def print_maximal_temporal_cliques(self):
        if len(self.clique_dict) == 0:
            self.get_maximal_temporal_cliques()
        for k_curr in self.clique_dict.keys():
            for X in self.clique_dict[k_curr].keys():
                print(X, self.clique_dict[k_curr][X])
                self.maximal_clique_count += len(self.clique_dict[k_curr][X])
                    
    def get_maximal_cliqu_count(self):
        if self.maximal_clique_count == 0:
            for k_curr in self.clique_dict.keys():
                for X in self.clique_dict[k_curr].keys():                    
                    for I in self.clique_dict[k_curr][X]:
                        self.maximal_clique_count += 1
                        
        return self.maximal_clique_count
        
    def get_all_temporal_cliques(self):
        
        for k_curr in range(2, self.delta_degeneracy + 2):
            for X in self.S_dict[k_curr].keys():
                
                k_len = len(X)
                if k_len > self.max_card:
                    self.max_card = k_len   
                '''
                    for card_key in range(2, self.max_card+1):
                        if card_key not in self.clique_dict.keys():
                            self.clique_dict[k_len] = defaultdict(list)
                '''

                i_s, i_e = -1, -1
                for i in range(self.Dz):
                    if i_s == -1 and i_e == -1:
                        if self.S_dict[k_curr][X][i] == True:
                            i_s, i_e = i, i
                    elif i_s > -1 and i_e > -1:
                        if self.S_dict[k_curr][X][i] == True:
                            i_e = i
                        else:
                            t_b = self.get_tb_te_from_snapshot_index(i_s)[0]
                            t_e = self.get_tb_te_from_snapshot_index(i_e)[1]                        
                            #stop# print(X, t_b, t_e)
                            self.clique_dict[k_curr][X].append(tuple([t_b, t_e]))
                            i_s, i_e = -1, -1 
                            if (t_e - t_b) > self.max_duration :
                                self.max_duration = t_e - t_b
                if i_s > -1 and i_e > -1:
                    t_b = self.get_tb_te_from_snapshot_index(i_s)[0]
                    t_e = self.get_tb_te_from_snapshot_index(i_e)[1]
                    #stop# print(X, t_b, t_e)
                    self.clique_dict[k_curr][X].append(tuple([t_b, t_e]))
                    if (t_e - t_b) > self.max_duration :
                        self.max_duration = t_e - t_b 
        return self.clique_dict
        
        
    def get_tb_te_from_snapshot_index(self, i):
        t_e = (i * self.dt) + self.Delta + self.t_b_
        t_b = t_e - self.Delta
        return [t_b, t_e]
    
    def get_count_all_temporal_cliques(self):
        if self.S_count is not None:
            return self.S_count
        
        if len(self.clique_dict) == 0:
            self.get_maximal_temporal_cliques()
        
        self.S_count = np.zeros([self.max_card -1 , int((self.max_duration - self.Delta)/self.dt)+1], dtype=int)
        for k_curr in self.clique_dict.keys():
            for X in self.clique_dict[k_curr].keys():
                for I in self.clique_dict[k_curr][X]:
                    duration = I[1]-I[0]
                    c = 1
                    while duration >= self.Delta:
                        self.S_count[len(X)-2][int((duration - self.Delta)/self.dt)] += c
                        c += 1
                        duration -= self.dt
                    #print(X,I, self.S_count)
        
        return self.S_count
