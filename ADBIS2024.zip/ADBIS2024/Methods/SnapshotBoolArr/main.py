import os
import pandas as pd
from collections import defaultdict
import math
import pickle
import time as TM
import psutil
import argparse
import sys

from util import create_graph, get_degeneracy_ordering
from temporal_clique_storage import TClique_storage
from clique_enumeration_static import Clique_Enum


parser = argparse.ArgumentParser()
parser.add_argument("--rootdir", type=str, help="Root directory of the project")
parser.add_argument("--dataset", type=str, help="Name of the dataset")
parser.add_argument("--filename", type=str, help="Name of the file to read data")
parser.add_argument("--method", type=str, help="Name of the algorithm(method) which is used to compute")
parser.add_argument("--delta", type=int, help="Integer Delta Value greater than zero")
parser.add_argument("--gamma", type=int, help="Integer gamma Value greater than zero")
parser.add_argument("--dt", type=int, help="Integer dt Value greater than zero")
parser.add_argument("--save", type=int, help="Integer Save Flag == 1 save result clique set", default=0)
args = parser.parse_args()

'''
rootdir = "C:\\Users\\hp\\Code\\Delta-Gamma-Clique\\Snapshot-based-enumeration"
#data_dir = "Dataset"
dataset = "toy"
filename = "sample_linked_stream.txt"


delta = 3
gamma = 1
dt = 1

'''
rootdir = args.rootdir
dataset = args.dataset
filename = args.filename
method = args.method
delta = args.delta
gamma = args.gamma
dt = args.dt
save = args.save

if len(sys.argv) == 1:
    print("Try -h to know the arguments")
    exit()
    
    
data_file = os.path.join(rootdir, "Dataset", dataset, filename)
result_dir = os.path.join(rootdir, "Results", dataset, method) 

if not os.path.exists(result_dir):
    # Create the directory
    os.makedirs(result_dir)




### Read Data
data = pd.read_csv(data_file, sep=" ", header=None)
data.columns =['t', 'u', 'v']
data = data.sort_values(by = ['t', 'u', 'v'], inplace=False,ignore_index=True)

print("Delta {}, gamma {}, dt {}".format(delta,gamma,dt))
t_b = min(data['t'])
t_e = max(data['t'])

t_b_ = t_b + (gamma - 1) * dt - delta
t_e_ = t_e - (gamma - 1) * dt + delta

print("t_b, t_e, t_b_, t_e_: ", t_b, t_e, t_b_, t_e_)
Dz = math.floor(((t_e_ - t_b_) - delta ) / dt) + 1  # the number of snapshot graphs
print("the number of snapshot graphs (Dz): ", Dz)




############# edge and node list creation for the snapshot graphs
snap_edge_list = dict()
snap_node_list = dict()
for i in range(Dz):
    snap_edge_list[t_b_ + i*dt] = defaultdict(int)
    snap_node_list[t_b_ + i*dt] = set()
    
for index, row in data.iterrows():
    for i in range(row['t'] - delta , row['t'] +dt,  dt):
        if i >= t_b_ and i<= t_e_ - delta:
            snap_edge_list[i][frozenset((row['u'], row['v']))] += 1 ## add edge with their count of occurence
            snap_node_list[i].add(row['u'])
            snap_node_list[i].add(row['v'])
            
            
############ Clique computation for each snapshot graph

delta_degen = []
for i in snap_edge_list.keys():
    G_t = create_graph(snap_edge_list[i])
    delta_degen.append(get_degeneracy_ordering(G_t)[1])
    del G_t
print("the Delta-Degeneracy: ", max(delta_degen))
start_time1 = TM.time()

TClique_S = TClique_storage(delta, t_b_, t_e_, dt, max(delta_degen)) 

for i in snap_edge_list.keys():
    #stop# print("Time start - Time end", i , i + delta)
    t_end = i + delta
    #G = create_graph(snap_edge_list[i])
    # i is the start time,
    Cn = Clique_Enum(snap_edge_list[i], [], gamma)
    
    Cn.find_cliques(approach="BKDegen")    
    for X in Cn.clique_list:
        TClique_S.add_clique_Deltasize(X, idx=None, t_e=t_end)
    del Cn

del snap_edge_list
del snap_node_list        
#### Get temporal cliques - array structure "S_dict"
#TClique_S.get_all_cliques() ## It only prints

#### Get all temporal cliques - list of (tb, te) structure "clique_dict"
TClique_S.get_all_temporal_cliques()  ## It forms as well prints

end_time1 = TM.time()

op_fname = "dm_clique_dict"+"_"+str(delta)+"_"+str(gamma)+".pkl" 
with open(os.path.join(result_dir, op_fname), 'wb') as file: 
    pickle.dump(TClique_S.clique_dict, file) 

### All Delta gamm - clique count        
print("All Delta,gamma Clique count - Result")
print(TClique_S.get_count_all_temporal_cliques())


start_time2 = TM.time()
### Get all Maximal Delta, gamma - cliques
TClique_S.get_maximal_temporal_cliques()
end_time2 = TM.time()


### Print All Maximal cliques
TClique_S.print_maximal_temporal_cliques()

if save == 1:
    op_fname = "maximal_clique_dict" + "_" + str(delta) + "_" + str(gamma) + ".pkl"         
    with open(os.path.join(result_dir, op_fname), 'wb') as file: 
        pickle.dump(TClique_S.clique_dict, file) 

    op_fname = "all_temporal_clique_count" + "_" + str(delta) + "_" + str(gamma) + ".pkl" 
    with open(os.path.join(result_dir, op_fname), 'wb') as file: 
        pickle.dump(TClique_S.S_count, file)

### Maximal Clique Counts and statistics
print("Maximal Clique Count: ", TClique_S.get_maximal_cliqu_count(), \
        "Maximum Cardinality: ", TClique_S.max_card, \
        "Maximum Duration: ", TClique_S.max_duration,\
        "Delta-degenracy: ", max(delta_degen))
        
### Computational Time and space
print("Computational Time: ", (end_time1 - start_time1) + (end_time2 - start_time2), "sec." )       
process = psutil.Process(os.getpid())
compspace = process.memory_info().rss/1024/1024
print("Used Memory:", compspace, "MB")


#### Stat result saving 
import json
base_result = dict()

base_result['dataset'] = dataset 
base_result['delta'] = delta
base_result['gamma'] = gamma

base_result['clique_count'] = TClique_S.get_maximal_cliqu_count()
base_result['maxsize'] = TClique_S.max_card
base_result['maxdur'] = TClique_S.max_duration

base_result['method'] = method
base_result['comptime'] = (end_time1 - start_time1) + (end_time2 - start_time2)
base_result['compspace'] = compspace

op_fname = "base_result"+"_"+str(delta)+"_"+str(gamma)+".json"
with open(os.path.join(result_dir, op_fname), "w") as file:
    json.dump(base_result, file)






