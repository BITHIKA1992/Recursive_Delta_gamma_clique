from util import create_graph, get_degeneracy_ordering, get_degree_ordering
import copy
from matplotlib import pyplot as plt
import networkx as nx
from collections import defaultdict

## Bron Kerbosch Algorithm
class Clique_Enum(object):
    def __init__(self, edge_list, node_list, gamma, G=None):
        if G is None:
            self.G = create_graph(edge_list, node_list, gamma)
        else:
            self.G = G
        self.degen_node_order, self.degeneracy = get_degeneracy_ordering(self.G) 
        #print(degen_node_order)
        self.clique_list = []
        self.clique_count = 0

    def find_cliques(self, approach='BK'):
        if self.clique_count > 0:
            self.clique_count = 0
            self.clique_list = []

        if approach == 'BK':
            self.BK_find_cliques(remaining_nodes=[n for n in self.G.nodes()])
        elif approach == "BKPivot":
            self.BKPivot_find_cliques(remaining_nodes=[n for n in self.G.nodes()])
        elif approach == "BKDegen":
            self.BKDegen_find_cliques()

        return self.clique_list

    def BK_find_cliques(self, potential_clique=[], remaining_nodes=[], skip_nodes=[], depth=0):
        #if len(potential_clique) > 1 and (len(remaining_nodes) > 0 or len(skip_nodes) > 0):
        #    print('This is a clique:', potential_clique)
        if len(remaining_nodes) == 0 and len(skip_nodes) == 0:
            #stop# print('This is a Maximal clique:', potential_clique)
            self.clique_list.append(potential_clique)
            self.clique_count += 1
            return 1 #[potential_clique] 

        found_cliques = 0 #[]
        search_nodes = copy.deepcopy(remaining_nodes)
        for node in search_nodes:
            new_potential_clique = potential_clique + [node]
            new_remaining_nodes = [n for n in remaining_nodes if n in self.G.neighbors(node)]
            new_skip_list = [n for n in skip_nodes if n in self.G.neighbors(node)]
            found_cliques += self.BK_find_cliques(new_potential_clique, new_remaining_nodes, new_skip_list, depth + 1)
            remaining_nodes.remove(node)
            skip_nodes.append(node)
        return found_cliques
    
    ## Tomita et al. -paper algorithm
    def BKPivot_find_cliques(self, potential_clique=[], remaining_nodes=[], skip_nodes=[], depth=0):
        #if len(potential_clique) > 1 and (len(remaining_nodes) > 0 or len(skip_nodes) > 0):
        #    print('This is a clique:', potential_clique)
        if len(remaining_nodes) == 0 and len(skip_nodes) == 0:
            #stop# print('This is a Maximal clique:', potential_clique)
            if len(potential_clique) > 1:
                self.clique_list.append(potential_clique)
                self.clique_count += 1
            return 1 #[potential_clique] 

        found_cliques = 0 #[]
        ## Pivot selection
        u = self.pivot_finder(remaining_nodes, skip_nodes)
        #print(u)
        search_nodes = [n for n in remaining_nodes if n not in self.G.neighbors(u)]
        
        for node in search_nodes:
            new_potential_clique = potential_clique + [node]
            new_remaining_nodes = [n for n in remaining_nodes if n in self.G.neighbors(node)]
            new_skip_list = [n for n in skip_nodes if n in self.G.neighbors(node)]
            found_cliques += self.BKPivot_find_cliques(new_potential_clique, new_remaining_nodes, new_skip_list, depth + 1)
            remaining_nodes.remove(node)
            skip_nodes.append(node)
        return found_cliques
    
    ## Degeneracy ordering based clique enumeration Eppstein et al.
    def BKDegen_find_cliques(self, potential_clique=[], remaining_nodes=[], skip_nodes=[], depth=0):
        for i, node in enumerate(self.degen_node_order):
            remaining_nodes = [n for n in self.degen_node_order[i+1:] if n in self.G.neighbors(node)]
            skip_nodes = [n for n in self.degen_node_order[:i] if n in self.G.neighbors(node)]
            potential_clique = [node]
            self.BKPivot_find_cliques(potential_clique, remaining_nodes, skip_nodes, depth=0)       
        return 
    
    def pivot_finder(self, P, X):
        PuX = list(set(P).union(set(X)))
        max_u = PuX[0]
        max_val = len([n for n in P if n in self.G.neighbors(max_u)])
        for node in PuX[1:]:
            node_val = len([n for n in P if n in self.G.neighbors(node)])
            if node_val > max_val:
                max_val = node_val
                max_u = node
        return max_u
    

             
    def plot_graph(self):
        nx.draw(self.G, with_labels = True)
        plt.show()

    ## find temporal clique - by adding the snap shot duration
        
        
    
if __name__=="__main__":
    node_list = ['A', 'B', 'C', 'D', 'E', 'F']
    
    edge_list = set( [frozenset(['A', 'B']), frozenset(['A', 'C']), frozenset(['A', 'E']),\
                     frozenset(['B', 'C']), frozenset(['B', 'D']), frozenset(['B', 'F']),\
                     frozenset(['C', 'D']), frozenset(['C', 'F']), frozenset(['D', 'E']), frozenset(['D', 'F'])])
    
    #edge_list = defaultdict(int)
    #edge_list[frozenset(['A', 'B'])] = 1
    #edge_list[frozenset(['A', 'C'])] = 1
    Cn = Clique_Enum(edge_list, node_list, 1)
    print("Node List                 ",  Cn.G.nodes())
    #print("Edge List                 ", [(u, v, Cn.G[u][v]['gamma']) for u, v in Cn.G.edges()])
    print("High Degree Node ordering ", get_degree_ordering(Cn.G))
    print("Degeneracy Ordering       ", get_degeneracy_ordering(Cn.G)[0])
    print(Cn.find_cliques(approach="BKDegen"))
    Cn.plot_graph()