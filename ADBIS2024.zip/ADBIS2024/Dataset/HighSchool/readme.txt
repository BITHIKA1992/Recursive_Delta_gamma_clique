nodecount: 327
linkcount: 188508
timeline: 363560 sec (approx 4.2 days)

work with: "highschoolProcessed.txt"
ordered with time, orginal data was taken 20 sec gap, changed it to form space between two timestamp as 1, to work with dt=1
t_transform =  original_t / 20 - 69200000

node_id not transformed